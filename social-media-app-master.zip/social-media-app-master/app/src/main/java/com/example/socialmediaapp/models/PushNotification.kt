package com.example.socialmediaapp.models

data class PushNotification(
    val data: NotificationData,
    val to: String
)
